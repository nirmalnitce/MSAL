import React from 'react';
const App = () => <div>Hello from App with MSAL + Redux</div>;
export default App;